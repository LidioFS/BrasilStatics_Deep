
import React, { useState, useEffect } from 'react';
import { RefreshCw, Trophy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import DateSelector from '@/components/matches/DateSelector';
import CompetitionGroup from '@/components/matches/CompetitionGroup';
import useUltimateFootballData from '@/hooks/useUltimateFootballData';
import { Fixture } from '@/types/football';

const Matches = () => {
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedAnalysis, setSelectedAnalysis] = useState<string>('');
  
  const { useSofascoreFixtures } = useUltimateFootballData();
  
  const { data: matchesData, isLoading, refetch } = useSofascoreFixtures(selectedDate);
  const fixtures: Fixture[] = matchesData?.response || [];

  // Obter tipo de análise da URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const analysisParam = urlParams.get('analysis');
    if (analysisParam) {
      setSelectedAnalysis(analysisParam);
    }
  }, []);

  // Agrupar jogos por competição
  const groupedMatches = fixtures.reduce((groups, match) => {
    const competitionKey = `${match.league.name}-${match.league.country}`;
    if (!groups[competitionKey]) {
      groups[competitionKey] = {
        competition: match.league.name,
        country: match.league.country,
        logo: match.league.logo,
        flag: match.league.flag,
        matches: []
      };
    }
    groups[competitionKey].matches.push(match);
    return groups;
  }, {} as Record<string, { competition: string; country: string; logo: string; flag: string; matches: Fixture[] }>);

  // Ordenar grupos: Mundial de Clubes primeiro, depois por nome
  const sortedGroups = Object.values(groupedMatches).sort((a, b) => {
    const aIsClubWorldCup = a.competition.toLowerCase().includes('club world cup') || a.competition.toLowerCase().includes('mundial');
    const bIsClubWorldCup = b.competition.toLowerCase().includes('club world cup') || b.competition.toLowerCase().includes('mundial');
    
    if (aIsClubWorldCup && !bIsClubWorldCup) return -1;
    if (!aIsClubWorldCup && bIsClubWorldCup) return 1;
    
    return a.competition.localeCompare(b.competition);
  });

  const getAnalysisTypeLabel = (type: string) => {
    const types: { [key: string]: string } = {
      'goals': '⚽ Análise de Gols',
      'corners': '📐 Análise de Escanteios',
      'cards': '🟨 Análise de Cartões',
      'shots': '🎯 Análise de Chutes',
      'asian_odds': '📊 Odds Asiáticas'
    };
    return types[type] || 'Análise Geral';
  };

  const totalMatches = fixtures.length;
  const liveCount = fixtures.filter(match => 
    ['LIVE', '1H', '2H', 'HT'].includes(match.status.short)
  ).length;
  const clubWorldCupCount = fixtures.filter(match =>
    match.league.name.toLowerCase().includes('club world cup') ||
    match.league.name.toLowerCase().includes('mundial')
  ).length;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            ⚽ Partidas de Futebol
          </h1>
          {selectedAnalysis && (
            <Badge variant="outline" className="mb-2 border-brasil-green text-brasil-green">
              {getAnalysisTypeLabel(selectedAnalysis)}
            </Badge>
          )}
          <div className="flex items-center justify-center space-x-4 text-sm text-muted-foreground">
            <span>{totalMatches} jogos</span>
            {liveCount > 0 && (
              <Badge className="bg-red-500 text-white">
                {liveCount} ao vivo
              </Badge>
            )}
            {clubWorldCupCount > 0 && (
              <Badge className="bg-brasil-green text-white">
                <Trophy className="w-3 h-3 mr-1" />
                {clubWorldCupCount} Mundial
              </Badge>
            )}
          </div>
        </div>

        {/* Date Selector */}
        <DateSelector
          selectedDate={selectedDate}
          onDateChange={setSelectedDate}
        />

        {/* Refresh Button */}
        <div className="flex justify-center mb-6">
          <Button 
            onClick={() => refetch()} 
            disabled={isLoading}
            variant="outline"
            className="border-brasil-green text-brasil-green hover:bg-brasil-green hover:text-white"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>

        {/* Competition Groups */}
        <div>
          {sortedGroups.map((group, index) => (
            <CompetitionGroup
              key={index}
              competition={group.competition}
              country={group.country}
              logo={group.logo}
              flag={group.flag}
              matches={group.matches}
              showAnalyzeButton={selectedAnalysis !== ''}
            />
          ))}
        </div>

        {/* Empty State */}
        {fixtures.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">⚽</div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              Nenhum jogo encontrado
            </h3>
            <p className="text-muted-foreground mb-4">
              Não há jogos disponíveis para {selectedDate === new Date().toISOString().split('T')[0] ? 'hoje' : 'esta data'}.
            </p>
            <Button 
              onClick={() => refetch()}
              className="bg-brasil-green hover:bg-brasil-green/90"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Tentar Novamente
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Matches;
