
import React, { useState } from 'react';
import { Target, TrendingUp, CornerDownRight, AlertTriangle, Zap } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const analysisTypes = [
    {
      id: 'goals',
      icon: Target,
      title: 'Análise de Gols',
      description: 'Over/Under gols, ambos marcam, mercados de gols',
      color: 'text-brasil-green',
      bgColor: 'bg-brasil-green/10',
      borderColor: 'border-brasil-green/30'
    },
    {
      id: 'corners',
      icon: CornerDownRight,
      title: 'Análise de Escanteios',
      description: 'Total de escanteios, handicap de escanteios',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      id: 'cards',
      icon: AlertTriangle,
      title: 'Análise de Cartões',
      description: 'Cartões amarelos, vermelhos, total de cartões',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200'
    },
    {
      id: 'shots',
      icon: Zap,
      title: 'Análise de Chutes',
      description: 'Chutes no gol, chutes fora, total de finalizações',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    },
    {
      id: 'asian_odds',
      icon: TrendingUp,
      title: 'Odds Asiáticas',
      description: 'Handicaps asiáticos, mercados especiais',
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200'
    }
  ];

  const handleAnalysisSelect = (analysisId: string) => {
    // Redirecionar para página de jogos com filtro de análise
    navigate(`/jogos?analysis=${analysisId}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            ⚽ Análise Inteligente de Futebol
          </h1>
          <p className="text-xl text-muted-foreground mb-2">
            Bem-vindo, {user?.email || 'Usuário'}!
          </p>
          <p className="text-muted-foreground">
            Escolha o tipo de análise que deseja realizar nas partidas
          </p>
        </div>

        {/* Mundial de Clubes Destaque */}
        <Card className="card-glass border-brasil-green/30 mb-8 bg-gradient-to-r from-brasil-green/5 to-brasil-yellow/5">
          <CardHeader className="text-center">
            <CardTitle className="text-foreground flex items-center justify-center space-x-2">
              <span>🏆</span>
              <span>FIFA Club World Cup 2025</span>
              <Badge className="bg-red-500 text-white animate-pulse">AO VIVO</Badge>
            </CardTitle>
            <CardDescription>
              Mundial de Clubes da FIFA acontecendo agora - Análises em tempo real disponíveis
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Tipos de Análise */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {analysisTypes.map(({ id, icon: Icon, title, description, color, bgColor, borderColor }) => (
            <Card 
              key={id}
              className={`card-glass ${borderColor} hover-brasil-effect cursor-pointer transition-all duration-300 hover:scale-105`}
              onClick={() => handleAnalysisSelect(id)}
            >
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 ${bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Icon className={`w-8 h-8 ${color}`} />
                </div>
                <CardTitle className="text-foreground text-lg">{title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-sm text-muted-foreground mb-4">
                  {description}
                </p>
                <Button 
                  className={`w-full ${color === 'text-brasil-green' ? 'bg-brasil-green hover:bg-brasil-green/90' : 'bg-primary hover:bg-primary/90'}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAnalysisSelect(id);
                  }}
                >
                  Iniciar Análise
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Informações Adicionais */}
        <Card className="card-glass border-brasil-green/20 mt-8">
          <CardHeader>
            <CardTitle className="text-foreground text-center">
              🤖 Como Funciona
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl mb-2">1️⃣</div>
                <h4 className="font-semibold text-foreground mb-1">Escolha a Análise</h4>
                <p className="text-sm text-muted-foreground">Selecione o tipo de mercado que deseja analisar</p>
              </div>
              <div>
                <div className="text-2xl mb-2">2️⃣</div>
                <h4 className="font-semibold text-foreground mb-1">Veja as Partidas</h4>
                <p className="text-sm text-muted-foreground">Navegue pelos jogos disponíveis ao vivo e futuros</p>
              </div>
              <div>
                <div className="text-2xl mb-2">3️⃣</div>
                <h4 className="font-semibold text-foreground mb-1">Análise IA</h4>
                <p className="text-sm text-muted-foreground">Receba insights inteligentes e sugestões de apostas</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
