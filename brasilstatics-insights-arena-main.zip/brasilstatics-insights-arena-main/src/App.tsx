
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/layout/ProtectedRoute";
import Navbar from "@/components/layout/Navbar";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Matches from "./pages/Matches";
import Analysis from "./pages/Analysis";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="*" element={
              <ProtectedRoute>
                <div className="min-h-screen bg-background">
                  <Navbar />
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/jogos" element={<Matches />} />
                    <Route path="/analises" element={<Analysis />} />
                    <Route path="/ranking" element={<div className="p-8 text-center text-muted-foreground">Página de Ranking em desenvolvimento...</div>} />
                    <Route path="/ao-vivo" element={<div className="p-8 text-center text-muted-foreground">Página de Jogos ao Vivo em desenvolvimento...</div>} />
                    <Route path="/configuracoes" element={<div className="p-8 text-center text-muted-foreground">Página de Configurações em desenvolvimento...</div>} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </div>
              </ProtectedRoute>
            } />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
