
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface BetSuggestion {
  type: string;
  description: string;
  odds: string;
  confidence: number;
}

export interface AnalysisResult {
  prediction: {
    homeScore: number;
    awayScore: number;
    confidence: number;
  };
  insights: string[];
  recommendation: string;
  riskLevel: 'low' | 'medium' | 'high';
  betSuggestions: {
    lowRisk: BetSuggestion;
    mediumRisk: BetSuggestion;
    highRisk: BetSuggestion;
  };
}

const useAIAnalysis = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedBet, setSelectedBet] = useState<{risk: string; bet: BetSuggestion} | null>(null);

  const generateBetSuggestions = (homeTeam: string, awayTeam: string): AnalysisResult['betSuggestions'] => {
    const suggestions = {
      goals: {
        lowRisk: {
          type: 'Over 1.5 Gols',
          description: `Ambas equipes costumam marcar. ${homeTeam} e ${awayTeam} têm médias ofensivas consistentes.`,
          odds: '@1.40',
          confidence: 85
        },
        mediumRisk: {
          type: 'Ambos Marcam - SIM',
          description: `${homeTeam} forte em casa, ${awayTeam} com bom ataque visitante.`,
          odds: '@1.75',
          confidence: 70
        },
        highRisk: {
          type: 'Over 3.5 Gols',
          description: 'Confronto histórico com muitos gols, defesas vulneráveis.',
          odds: '@3.20',
          confidence: 45
        }
      },
      corners: {
        lowRisk: {
          type: 'Over 8.5 Escanteios',
          description: 'Média histórica de escanteios entre essas equipes é alta.',
          odds: '@1.50',
          confidence: 80
        },
        mediumRisk: {
          type: 'Over 10.5 Escanteios',
          description: 'Jogo deve ser disputado com muitos ataques pelas laterais.',
          odds: '@1.95',
          confidence: 65
        },
        highRisk: {
          type: 'Over 13.5 Escanteios',
          description: 'Equipes costumam pressionar muito nos minutos finais.',
          odds: '@4.10',
          confidence: 40
        }
      }
    };

    const randomType = Math.random() > 0.5 ? 'goals' : 'corners';
    return suggestions[randomType];
  };

  const analyzeMatch = async (
    fixtureId: number, 
    homeTeam: string, 
    awayTeam: string, 
    league: string,
    analysisType: 'goals' | 'corners' | 'cards' | 'shots' | 'asian_odds' = 'goals'
  ): Promise<AnalysisResult> => {
    setIsAnalyzing(true);
    
    try {
      console.log(`🤖 Iniciando análise IA (${analysisType}) para: ${homeTeam} vs ${awayTeam}`);
      
      // Simular análise IA baseada no tipo selecionado
      await new Promise(resolve => setTimeout(resolve, 2500));
      
      const betSuggestions = generateBetSuggestions(homeTeam, awayTeam);
      
      const analysisTypeInsights = {
        goals: [
          `${homeTeam} marcou em ${Math.floor(Math.random() * 3 + 7)} dos últimos 10 jogos em casa`,
          `${awayTeam} sofreu gols em ${Math.floor(Math.random() * 4 + 6)} dos últimos 10 jogos fora`,
          `Média de gols nos confrontos diretos: ${(Math.random() * 1.5 + 2.2).toFixed(1)} por jogo`,
          `Ambas equipes marcaram em ${Math.floor(Math.random() * 30 + 60)}% dos jogos recentes`
        ],
        corners: [
          `${homeTeam} tem média de ${(Math.random() * 2 + 5).toFixed(1)} escanteios por jogo em casa`,
          `${awayTeam} força ${(Math.random() * 2 + 4).toFixed(1)} escanteios por jogo como visitante`,
          `Últimos 5 confrontos tiveram média de ${(Math.random() * 3 + 9).toFixed(1)} escanteios`,
          'Estilo de jogo sugere muitos ataques pelas laterais'
        ],
        cards: [
          `${homeTeam} recebeu ${Math.floor(Math.random() * 8 + 15)} cartões nos últimos 10 jogos`,
          `${awayTeam} tem média de ${(Math.random() * 0.8 + 1.2).toFixed(1)} cartões por jogo fora`,
          `Árbitro da partida tem média de ${(Math.random() * 1.5 + 3.5).toFixed(1)} cartões por jogo`,
          'Confronto histórico com certa rivalidade e intensidade'
        ],
        shots: [
          `${homeTeam} tem média de ${(Math.random() * 4 + 12).toFixed(1)} chutes por jogo`,
          `${awayTeam} permite ${(Math.random() * 3 + 10).toFixed(1)} chutes no gol por partida`,
          `Eficiência de finalização: ${homeTeam} ${(Math.random() * 10 + 15).toFixed(1)}%`,
          'Estilo ofensivo promete muitas finalizações'
        ],
        asian_odds: [
          `${homeTeam} venceu ${Math.floor(Math.random() * 3 + 6)} dos últimos 10 jogos em casa`,
          `${awayTeam} não perde há ${Math.floor(Math.random() * 3 + 3)} jogos fora de casa`,
          `Handicap histórico favorece ${Math.random() > 0.5 ? homeTeam : awayTeam}`,
          'Mercado asiático oferece boas oportunidades de value'
        ]
      };

      const mockAnalysis: AnalysisResult = {
        prediction: {
          homeScore: Math.floor(Math.random() * 3 + 1),
          awayScore: Math.floor(Math.random() * 3 + 1),
          confidence: Math.floor(Math.random() * 25 + 70)
        },
        insights: analysisTypeInsights[analysisType],
        recommendation: `Análise ${analysisType.toUpperCase()}: ${betSuggestions.mediumRisk.type}`,
        riskLevel: Math.random() > 0.6 ? 'low' : Math.random() > 0.3 ? 'medium' : 'high',
        betSuggestions
      };
      
      console.log('✅ Análise concluída:', mockAnalysis);
      return mockAnalysis;
      
    } catch (error) {
      console.error('❌ Erro na análise:', error);
      throw new Error('Falha na análise do jogo');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generateQuickInsight = (homeTeam: string, awayTeam: string): string => {
    const insights = [
      `Clássico entre ${homeTeam} e ${awayTeam} promete muita emoção`,
      `Confronto equilibrado com leve vantagem para ${Math.random() > 0.5 ? homeTeam : awayTeam}`,
      `Jogo pode ter mais de 2.5 gols baseado no histórico`,
      `Defesas sólidas sugerem Under 2.5 gols`,
      `Ambos os times têm poder ofensivo para marcar`,
      `${homeTeam} busca manter invencibilidade em casa`,
      `${awayTeam} precisa da vitória para subir na tabela`
    ];
    
    return insights[Math.floor(Math.random() * insights.length)];
  };

  const selectBet = (risk: 'low' | 'medium' | 'high', bet: BetSuggestion) => {
    setSelectedBet({ risk, bet });
    console.log(`🎯 Aposta selecionada (${risk}):`, bet);
  };

  return {
    analyzeMatch,
    generateQuickInsight,
    selectBet,
    selectedBet,
    isAnalyzing
  };
};

export default useAIAnalysis;
