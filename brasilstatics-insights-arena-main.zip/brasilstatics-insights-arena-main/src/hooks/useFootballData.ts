
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const useFootballData = () => {
  const callAPI = async (endpoint: string, params: Record<string, string> = {}) => {
    console.log('🚀 Calling Football-Data API with:', { endpoint, params });
    
    try {
      const requestBody = { endpoint, params };
      console.log('📤 Request body:', JSON.stringify(requestBody));

      const { data, error } = await supabase.functions.invoke('football-data', {
        body: requestBody,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (error) {
        console.error('💥 Supabase function error:', error);
        throw new Error(`Supabase error: ${error.message}`);
      }

      console.log('✅ Football-Data API response received:', data);
      return data;
    } catch (error) {
      console.error('❌ API call failed:', error);
      throw error;
    }
  };

  return {
    // Buscar todas as competições
    useCompetitions: () => useQuery({
      queryKey: ['football-data-competitions'],
      queryFn: () => callAPI('competitions'),
      staleTime: 1000 * 60 * 60 * 24, // 24 horas
      retry: 2,
    }),

    // Buscar jogos por data
    useMatchesByDate: (date: string) => useQuery({
      queryKey: ['football-data-matches', date],
      queryFn: () => callAPI('matches', { date }),
      enabled: !!date,
      staleTime: 1000 * 60 * 5, // 5 minutos
      retry: 2,
    }),

    // Buscar jogos de uma competição específica
    useCompetitionMatches: (competitionId: string, date?: string) => useQuery({
      queryKey: ['football-data-competition-matches', competitionId, date],
      queryFn: () => callAPI('competition-matches', { 
        competition: competitionId, 
        ...(date && { date }) 
      }),
      enabled: !!competitionId,
      staleTime: 1000 * 60 * 5, // 5 minutos
      retry: 2,
    }),

    // Buscar jogos ao vivo
    useLiveMatches: () => useQuery({
      queryKey: ['football-data-live-matches'],
      queryFn: () => callAPI('matches-live'),
      refetchInterval: 30000, // 30 segundos
      retry: 2,
    }),

    // Teste direto da API
    testAPI: async () => {
      console.log('🧪 Testing Football-Data API connection...');
      try {
        const result = await callAPI('competitions');
        console.log('🧪 Test result:', result);
        return result;
      } catch (error) {
        console.error('🧪 Test failed:', error);
        throw error;
      }
    },
  };
};

export default useFootballData;
