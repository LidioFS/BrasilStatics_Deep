
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const useFootballAPI = () => {
  const callAPI = async (endpoint: string, params: Record<string, string> = {}) => {
    console.log('🚀 Calling API with:', { endpoint, params });
    
    try {
      const requestBody = { endpoint, params };
      console.log('📤 Request body:', JSON.stringify(requestBody));

      const { data, error } = await supabase.functions.invoke('football-api', {
        body: requestBody,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (error) {
        console.error('💥 Supabase function error:', error);
        throw new Error(`Supabase error: ${error.message}`);
      }

      console.log('✅ API response received:', {
        results: data?.results || 0,
        response_length: data?.response?.length || 0,
        errors: data?.errors || [],
        raw_data: data
      });

      // Verificar se a API retornou erros
      if (data?.errors && data.errors.length > 0) {
        console.error('⚠️ API-FOOTBALL errors:', data.errors);
        throw new Error(`API-FOOTBALL error: ${data.errors.join(', ')}`);
      }

      // Se não há dados de resposta, criar estrutura padrão
      if (!data?.response) {
        console.warn('⚠️ No response data from API');
        return {
          results: 0,
          response: [],
          errors: []
        };
      }

      return data;
    } catch (error) {
      console.error('❌ API call failed:', error);
      throw error;
    }
  };

  const analyzeGame = async (fixtureId: number, analysisType: string = 'gols') => {
    console.log('🔍 Analyzing game:', { fixtureId, analysisType });
    
    try {
      const { data, error } = await supabase.functions.invoke('analyze-game', {
        body: { fixture_id: fixtureId, type: analysisType },
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (error) {
        console.error('💥 Analysis error:', error);
        throw new Error(`Analysis error: ${error.message}`);
      }

      console.log('✅ Analysis result:', data);
      return data;
    } catch (error) {
      console.error('❌ Analysis failed:', error);
      throw error;
    }
  };

  return {
    // Buscar todas as ligas
    useLeagues: () => useQuery({
      queryKey: ['leagues'],
      queryFn: () => callAPI('leagues'),
      staleTime: 1000 * 60 * 60 * 24, // 24 horas
      retry: (failureCount, error) => {
        console.log(`🔄 Retry attempt ${failureCount} for leagues:`, error?.message);
        return failureCount < 2;
      },
      retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
    }),

    // Buscar jogos por data
    useFixturesByDate: (date: string, league?: string) => useQuery({
      queryKey: ['fixtures', date, league],
      queryFn: () => {
        console.log('📅 Fetching fixtures for:', { date, league });
        return callAPI('fixtures', { date, ...(league && { league }) });
      },
      enabled: !!date,
      staleTime: 1000 * 60 * 5, // 5 minutos
      retry: (failureCount, error) => {
        console.log(`🔄 Retry attempt ${failureCount} for fixtures:`, error?.message);
        return failureCount < 3;
      },
      retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
    }),

    // Buscar jogos ao vivo
    useLiveFixtures: () => useQuery({
      queryKey: ['fixtures-live'],
      queryFn: () => callAPI('fixtures-live'),
      refetchInterval: 30000, // 30 segundos
      retry: 2,
    }),

    // Buscar jogos de hoje
    useTodayFixtures: () => useQuery({
      queryKey: ['fixtures-today'],
      queryFn: () => callAPI('fixtures-today'),
      staleTime: 1000 * 60 * 5, // 5 minutos
      retry: 2,
    }),

    // Teste direto da API
    testAPI: async () => {
      console.log('🧪 Testing API connection...');
      try {
        const result = await callAPI('leagues');
        console.log('🧪 Test result:', result);
        return result;
      } catch (error) {
        console.error('🧪 Test failed:', error);
        throw error;
      }
    },

    // Analisar jogo
    analyzeGame
  };
};

export default useFootballAPI;
