
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const useScrapingFootball = () => {
  const callScrapingAPI = async () => {
    console.log('🕷️ Calling scraping football API...');
    
    try {
      const { data, error } = await supabase.functions.invoke('scrape-football', {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (error) {
        console.error('💥 Scraping API error:', error);
        throw new Error(`Scraping error: ${error.message}`);
      }

      console.log('✅ Scraping API response:', {
        results: data?.results || 0,
        response_length: data?.response?.length || 0
      });

      return data;
    } catch (error) {
      console.error('❌ Scraping API call failed:', error);
      throw error;
    }
  };

  return {
    // Hook para buscar jogos via scraping
    useScrapedFixtures: () => useQuery({
      queryKey: ['scraped-fixtures'],
      queryFn: callScrapingAPI,
      staleTime: 1000 * 60 * 10, // 10 minutos
      retry: 2,
    }),

    // Teste direto da API de scraping
    testScrapingAPI: async () => {
      console.log('🧪 Testing scraping API...');
      try {
        const result = await callScrapingAPI();
        console.log('🧪 Scraping test result:', result);
        return result;
      } catch (error) {
        console.error('🧪 Scraping test failed:', error);
        throw error;
      }
    },
  };
};

export default useScrapingFootball;
