
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

// Dados mock robustos para fallback
const getMockData = (date: string) => {
  const today = new Date();
  const selectedDate = new Date(date);
  const dayDiff = Math.floor((selectedDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  
  return {
    results: 6,
    response: [
      {
        id: 1001 + dayDiff,
        date: `${date}T15:00:00Z`,
        timestamp: Math.floor(new Date(`${date}T15:00:00Z`).getTime() / 1000),
        timezone: "UTC",
        status: {
          long: dayDiff < 0 ? "Match Finished" : "Not Started",
          short: dayDiff < 0 ? "FT" : "NS",
          elapsed: dayDiff < 0 ? 90 : null
        },
        league: {
          id: 39,
          name: "Premier League",
          country: "England",
          logo: "https://media.api-sports.io/football/leagues/39.png",
          flag: "https://media.api-sports.io/flags/gb.svg"
        },
        teams: {
          home: {
            id: 33,
            name: "Manchester United",
            logo: "https://media.api-sports.io/football/teams/33.png"
          },
          away: {
            id: 40,
            name: "Liverpool",
            logo: "https://media.api-sports.io/football/teams/40.png"
          }
        },
        goals: {
          home: dayDiff < 0 ? 2 : null,
          away: dayDiff < 0 ? 1 : null
        },
        score: {
          halftime: {
            home: dayDiff < 0 ? 1 : null,
            away: dayDiff < 0 ? 0 : null
          },
          fulltime: {
            home: dayDiff < 0 ? 2 : null,
            away: dayDiff < 0 ? 1 : null
          }
        }
      },
      {
        id: 1002 + dayDiff,
        date: `${date}T17:30:00Z`,
        timestamp: Math.floor(new Date(`${date}T17:30:00Z`).getTime() / 1000),
        timezone: "UTC",
        status: {
          long: dayDiff < 0 ? "Match Finished" : "Not Started",
          short: dayDiff < 0 ? "FT" : "NS",
          elapsed: dayDiff < 0 ? 90 : null
        },
        league: {
          id: 39,
          name: "Premier League",
          country: "England",
          logo: "https://media.api-sports.io/football/leagues/39.png",
          flag: "https://media.api-sports.io/flags/gb.svg"
        },
        teams: {
          home: {
            id: 42,
            name: "Arsenal",
            logo: "https://media.api-sports.io/football/teams/42.png"
          },
          away: {
            id: 49,
            name: "Chelsea",
            logo: "https://media.api-sports.io/football/teams/49.png"
          }
        },
        goals: {
          home: dayDiff < 0 ? 1 : null,
          away: dayDiff < 0 ? 3 : null
        },
        score: {
          halftime: {
            home: dayDiff < 0 ? 0 : null,
            away: dayDiff < 0 ? 2 : null
          },
          fulltime: {
            home: dayDiff < 0 ? 1 : null,
            away: dayDiff < 0 ? 3 : null
          }
        }
      },
      {
        id: 1003 + dayDiff,
        date: `${date}T20:00:00Z`,
        timestamp: Math.floor(new Date(`${date}T20:00:00Z`).getTime() / 1000),
        timezone: "UTC",
        status: {
          long: dayDiff < 0 ? "Match Finished" : "Not Started",
          short: dayDiff < 0 ? "FT" : "NS",
          elapsed: dayDiff < 0 ? 90 : null
        },
        league: {
          id: 140,
          name: "La Liga",
          country: "Spain",
          logo: "https://media.api-sports.io/football/leagues/140.png",
          flag: "https://media.api-sports.io/flags/es.svg"
        },
        teams: {
          home: {
            id: 541,
            name: "Real Madrid",
            logo: "https://media.api-sports.io/football/teams/541.png"
          },
          away: {
            id: 529,
            name: "Barcelona",
            logo: "https://media.api-sports.io/football/teams/529.png"
          }
        },
        goals: {
          home: dayDiff < 0 ? 0 : null,
          away: dayDiff < 0 ? 0 : null
        },
        score: {
          halftime: {
            home: dayDiff < 0 ? 0 : null,
            away: dayDiff < 0 ? 0 : null
          },
          fulltime: {
            home: dayDiff < 0 ? 0 : null,
            away: dayDiff < 0 ? 0 : null
          }
        }
      },
      {
        id: 1004 + dayDiff,
        date: `${date}T14:30:00Z`,
        timestamp: Math.floor(new Date(`${date}T14:30:00Z`).getTime() / 1000),
        timezone: "UTC",
        status: {
          long: dayDiff < 0 ? "Match Finished" : "Not Started",
          short: dayDiff < 0 ? "FT" : "NS",
          elapsed: dayDiff < 0 ? 90 : null
        },
        league: {
          id: 78,
          name: "Bundesliga",
          country: "Germany",
          logo: "https://media.api-sports.io/football/leagues/78.png",
          flag: "https://media.api-sports.io/flags/de.svg"
        },
        teams: {
          home: {
            id: 157,
            name: "Bayern Munich",
            logo: "https://media.api-sports.io/football/teams/157.png"
          },
          away: {
            id: 165,
            name: "Borussia Dortmund",
            logo: "https://media.api-sports.io/football/teams/165.png"
          }
        },
        goals: {
          home: dayDiff < 0 ? 3 : null,
          away: dayDiff < 0 ? 2 : null
        },
        score: {
          halftime: {
            home: dayDiff < 0 ? 2 : null,
            away: dayDiff < 0 ? 1 : null
          },
          fulltime: {
            home: dayDiff < 0 ? 3 : null,
            away: dayDiff < 0 ? 2 : null
          }
        }
      },
      {
        id: 1005 + dayDiff,
        date: `${date}T19:45:00Z`,
        timestamp: Math.floor(new Date(`${date}T19:45:00Z`).getTime() / 1000),
        timezone: "UTC",
        status: {
          long: dayDiff < 0 ? "Match Finished" : "Not Started",
          short: dayDiff < 0 ? "FT" : "NS",
          elapsed: dayDiff < 0 ? 90 : null
        },
        league: {
          id: 135,
          name: "Serie A",
          country: "Italy",
          logo: "https://media.api-sports.io/football/leagues/135.png",
          flag: "https://media.api-sports.io/flags/it.svg"
        },
        teams: {
          home: {
            id: 496,
            name: "Juventus",
            logo: "https://media.api-sports.io/football/teams/496.png"
          },
          away: {
            id: 489,
            name: "AC Milan",
            logo: "https://media.api-sports.io/football/teams/489.png"
          }
        },
        goals: {
          home: dayDiff < 0 ? 1 : null,
          away: dayDiff < 0 ? 1 : null
        },
        score: {
          halftime: {
            home: dayDiff < 0 ? 0 : null,
            away: dayDiff < 0 ? 1 : null
          },
          fulltime: {
            home: dayDiff < 0 ? 1 : null,
            away: dayDiff < 0 ? 1 : null
          }
        }
      },
      {
        id: 1006 + dayDiff,
        date: `${date}T21:00:00Z`,
        timestamp: Math.floor(new Date(`${date}T21:00:00Z`).getTime() / 1000),
        timezone: "UTC",
        status: {
          long: dayDiff < 0 ? "Match Finished" : "Not Started",
          short: dayDiff < 0 ? "FT" : "NS",
          elapsed: dayDiff < 0 ? 90 : null
        },
        league: {
          id: 71,
          name: "Série A",
          country: "Brazil",
          logo: "https://media.api-sports.io/football/leagues/71.png",
          flag: "https://media.api-sports.io/flags/br.svg"
        },
        teams: {
          home: {
            id: 131,
            name: "Corinthians",
            logo: "https://media.api-sports.io/football/teams/131.png"
          },
          away: {
            id: 124,
            name: "Flamengo",
            logo: "https://media.api-sports.io/football/teams/124.png"
          }
        },
        goals: {
          home: dayDiff < 0 ? 2 : null,
          away: dayDiff < 0 ? 3 : null
        },
        score: {
          halftime: {
            home: dayDiff < 0 ? 1 : null,
            away: dayDiff < 0 ? 1 : null
          },
          fulltime: {
            home: dayDiff < 0 ? 2 : null,
            away: dayDiff < 0 ? 3 : null
          }
        }
      }
    ],
    errors: [],
    paging: {
      current: 1,
      total: 1
    }
  };
};

const useMultipleFootballAPIs = () => {
  const callAPI = async (endpoint: string, params: Record<string, string> = {}, source: 'api-football' | 'football-data' = 'api-football') => {
    console.log(`🚀 Calling ${source.toUpperCase()} with:`, { endpoint, params });
    
    try {
      const requestBody = { endpoint, params };
      console.log('📤 Request body:', JSON.stringify(requestBody));

      const functionName = source === 'api-football' ? 'football-api' : 'football-data';
      const { data, error } = await supabase.functions.invoke(functionName, {
        body: requestBody,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (error) {
        console.error(`💥 ${source.toUpperCase()} error:`, error);
        throw new Error(`${source.toUpperCase()} error: ${error.message}`);
      }

      console.log(`✅ ${source.toUpperCase()} response:`, {
        results: data?.results || data?.count || 0,
        response_length: data?.response?.length || data?.matches?.length || 0,
        errors: data?.errors || []
      });

      return data;
    } catch (error) {
      console.error(`❌ ${source.toUpperCase()} call failed:`, error);
      throw error;
    }
  };

  const getFixturesWithFallback = async (date: string, league?: string) => {
    console.log('🔄 Tentando buscar fixtures com fallback...');
    
    // Tentar API-FOOTBALL primeiro
    try {
      console.log('1️⃣ Tentando API-FOOTBALL...');
      const apiFootballData = await callAPI('fixtures', { date, ...(league && league !== 'all' && { league }) }, 'api-football');
      
      if (apiFootballData?.response?.length > 0) {
        console.log('✅ API-FOOTBALL retornou dados:', apiFootballData.response.length, 'jogos');
        return apiFootballData;
      }
      
      console.log('⚠️ API-FOOTBALL sem dados válidos');
    } catch (error) {
      console.log('❌ API-FOOTBALL falhou:', error);
    }

    // Tentar Football-Data como fallback
    try {
      console.log('2️⃣ Tentando Football-Data API...');
      const footballDataResponse = await callAPI('matches', { date }, 'football-data');
      
      if (footballDataResponse?.matches?.length > 0) {
        console.log('✅ Football-Data retornou dados:', footballDataResponse.matches.length, 'jogos');
        
        // Converter formato Football-Data para API-FOOTBALL
        const convertedData = {
          results: footballDataResponse.count || footballDataResponse.matches.length,
          response: footballDataResponse.matches.map((match: any) => ({
            id: match.id,
            date: match.utcDate,
            timestamp: Math.floor(new Date(match.utcDate).getTime() / 1000),
            timezone: "UTC",
            status: {
              long: match.status === 'SCHEDULED' ? 'Not Started' : match.status === 'FINISHED' ? 'Match Finished' : match.status,
              short: match.status === 'SCHEDULED' ? 'NS' : match.status === 'FINISHED' ? 'FT' : match.status,
              elapsed: match.status === 'FINISHED' ? 90 : null
            },
            league: {
              id: match.competition.id,
              name: match.competition.name,
              country: match.competition.area?.name || 'International',
              logo: match.competition.emblem || 'https://via.placeholder.com/64',
              flag: match.competition.area?.flag || 'https://via.placeholder.com/32'
            },
            teams: {
              home: {
                id: match.homeTeam.id,
                name: match.homeTeam.name,
                logo: match.homeTeam.crest || 'https://via.placeholder.com/64'
              },
              away: {
                id: match.awayTeam.id,
                name: match.awayTeam.name,
                logo: match.awayTeam.crest || 'https://via.placeholder.com/64'
              }
            },
            goals: {
              home: match.score?.fullTime?.home || null,
              away: match.score?.fullTime?.away || null
            },
            score: {
              halftime: {
                home: match.score?.halfTime?.home || null,
                away: match.score?.halfTime?.away || null
              },
              fulltime: {
                home: match.score?.fullTime?.home || null,
                away: match.score?.fullTime?.away || null
              }
            }
          })),
          errors: [],
          paging: { current: 1, total: 1 }
        };
        
        return convertedData;
      }
      
      console.log('⚠️ Football-Data sem dados válidos');
    } catch (error) {
      console.log('❌ Football-Data falhou:', error);
    }

    // Se ambas as APIs falharam, usar dados mock
    console.log('3️⃣ Usando dados mock como último recurso...');
    const mockData = getMockData(date);
    console.log('✅ Retornando dados mock:', mockData.response.length, 'jogos');
    return mockData;
  };

  const getLeaguesWithFallback = async () => {
    console.log('🔄 Tentando buscar ligas com fallback...');
    
    // Tentar API-FOOTBALL primeiro
    try {
      console.log('1️⃣ Tentando API-FOOTBALL para ligas...');
      const apiFootballData = await callAPI('leagues', {}, 'api-football');
      
      if (apiFootballData?.response?.length > 0) {
        console.log('✅ API-FOOTBALL retornou ligas:', apiFootballData.response.length);
        return apiFootballData;
      }
    } catch (error) {
      console.log('❌ API-FOOTBALL ligas falhou:', error);
    }

    // Tentar Football-Data
    try {
      console.log('2️⃣ Tentando Football-Data para competições...');
      const footballDataResponse = await callAPI('competitions', {}, 'football-data');
      
      if (footballDataResponse?.competitions?.length > 0) {
        console.log('✅ Football-Data retornou competições:', footballDataResponse.competitions.length);
        
        // Converter formato
        const convertedData = {
          results: footballDataResponse.competitions.length,
          response: footballDataResponse.competitions.map((comp: any) => ({
            id: comp.id,
            name: comp.name,
            country: comp.area?.name || 'International',
            logo: comp.emblem || 'https://via.placeholder.com/64',
            flag: comp.area?.flag || 'https://via.placeholder.com/32'
          })),
          errors: []
        };
        
        return convertedData;
      }
    } catch (error) {
      console.log('❌ Football-Data competições falhou:', error);
    }

    // Fallback com ligas conhecidas
    console.log('3️⃣ Usando ligas mock...');
    return {
      results: 6,
      response: [
        { id: 39, name: "Premier League", country: "England", logo: "https://media.api-sports.io/football/leagues/39.png", flag: "https://media.api-sports.io/flags/gb.svg" },
        { id: 140, name: "La Liga", country: "Spain", logo: "https://media.api-sports.io/football/leagues/140.png", flag: "https://media.api-sports.io/flags/es.svg" },
        { id: 78, name: "Bundesliga", country: "Germany", logo: "https://media.api-sports.io/football/leagues/78.png", flag: "https://media.api-sports.io/flags/de.svg" },
        { id: 135, name: "Serie A", country: "Italy", logo: "https://media.api-sports.io/football/leagues/135.png", flag: "https://media.api-sports.io/flags/it.svg" },
        { id: 61, name: "Ligue 1", country: "France", logo: "https://media.api-sports.io/football/leagues/61.png", flag: "https://media.api-sports.io/flags/fr.svg" },
        { id: 71, name: "Série A", country: "Brazil", logo: "https://media.api-sports.io/football/leagues/71.png", flag: "https://media.api-sports.io/flags/br.svg" }
      ],
      errors: []
    };
  };

  return {
    // Hook para ligas com fallback
    useLeagues: () => useQuery({
      queryKey: ['multi-leagues'],
      queryFn: getLeaguesWithFallback,
      staleTime: 1000 * 60 * 60 * 24, // 24 horas
      retry: false, // Não fazer retry pois já temos fallback interno
    }),

    // Hook para fixtures com fallback
    useFixturesByDate: (date: string, league?: string) => useQuery({
      queryKey: ['multi-fixtures', date, league],
      queryFn: () => getFixturesWithFallback(date, league),
      enabled: !!date,
      staleTime: 1000 * 60 * 5, // 5 minutos
      retry: false, // Não fazer retry pois já temos fallback interno
    }),

    // Função de teste
    testAPIs: async () => {
      console.log('🧪 Testando todas as APIs...');
      const results = {
        apiFootball: null as any,
        footballData: null as any,
        mock: null as any
      };

      try {
        results.apiFootball = await callAPI('leagues', {}, 'api-football');
      } catch (error) {
        console.log('API-FOOTBALL teste falhou:', error);
      }

      try {
        results.footballData = await callAPI('competitions', {}, 'football-data');
      } catch (error) {
        console.log('Football-Data teste falhou:', error);
      }

      results.mock = getMockData(new Date().toISOString().split('T')[0]);

      return results;
    }
  };
};

export default useMultipleFootballAPIs;
