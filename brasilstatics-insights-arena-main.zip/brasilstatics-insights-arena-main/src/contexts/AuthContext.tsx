
import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { AuthState, LoginCredentials, RegisterData, User } from '@/types/auth';
import { toast } from '@/hooks/use-toast';

type AuthAction = 
  | { type: 'LOGIN_START' }
  | { type: 'LOGIN_SUCCESS'; payload: { user: User; token: string } }
  | { type: 'LOGIN_FAILURE'; payload: string }
  | { type: 'LOGOUT' }
  | { type: 'SET_LOADING'; payload: boolean };

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => void;
  register: (data: RegisterData) => Promise<void>;
  canRegister: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const initialState: AuthState = {
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: false,
};

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case 'LOGIN_START':
      return { ...state, isLoading: true };
    case 'LOGIN_SUCCESS':
      return {
        ...state,
        user: action.payload.user,
        token: action.payload.token,
        isAuthenticated: true,
        isLoading: false,
      };
    case 'LOGIN_FAILURE':
      return {
        ...state,
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false,
      };
    case 'LOGOUT':
      return initialState;
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    default:
      return state;
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  useEffect(() => {
    // Verificar se há token salvo no localStorage
    const token = localStorage.getItem('brasilstatics_token');
    const user = localStorage.getItem('brasilstatics_user');
    
    if (token && user) {
      try {
        const parsedUser = JSON.parse(user);
        dispatch({
          type: 'LOGIN_SUCCESS',
          payload: { user: parsedUser, token }
        });
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('brasilstatics_token');
        localStorage.removeItem('brasilstatics_user');
      }
    }
  }, []);

  const login = async (credentials: LoginCredentials) => {
    dispatch({ type: 'LOGIN_START' });
    
    try {
      // Simulação de login - em produção seria uma chamada para o backend
      console.log('Attempting login with:', credentials);
      
      // Simular delay de rede
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Credenciais de teste
      if (credentials.username === 'lidiofs' && credentials.password === 'master123') {
        const user: User = {
          id: '1',
          username: 'lidiofs',
          email: 'lidiofs@brasilstatics.com',
          role: 'master',
          createdAt: new Date().toISOString(),
        };
        
        const token = 'mock-jwt-token-' + Date.now();
        
        localStorage.setItem('brasilstatics_token', token);
        localStorage.setItem('brasilstatics_user', JSON.stringify(user));
        
        dispatch({
          type: 'LOGIN_SUCCESS',
          payload: { user, token }
        });
        
        toast({
          title: "Login realizado com sucesso!",
          description: `Bem-vindo ao BrasilStatics, ${user.username}!`,
        });
      } else {
        throw new Error('Credenciais inválidas');
      }
    } catch (error) {
      console.error('Login error:', error);
      dispatch({ type: 'LOGIN_FAILURE', payload: error instanceof Error ? error.message : 'Erro no login' });
      toast({
        title: "Erro no login",
        description: error instanceof Error ? error.message : 'Credenciais inválidas',
        variant: "destructive",
      });
    }
  };

  const logout = () => {
    localStorage.removeItem('brasilstatics_token');
    localStorage.removeItem('brasilstatics_user');
    dispatch({ type: 'LOGOUT' });
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso.",
    });
  };

  const register = async (data: RegisterData) => {
    if (!state.user || state.user.role !== 'master') {
      throw new Error('Apenas o usuário master pode registrar novos usuários');
    }
    
    dispatch({ type: 'SET_LOADING', payload: true });
    
    try {
      // Simulação de registro - em produção seria uma chamada para o backend
      console.log('Registering new user:', data);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Usuário registrado com sucesso!",
        description: `O usuário ${data.username} foi criado.`,
      });
    } catch (error) {
      console.error('Registration error:', error);
      toast({
        title: "Erro no registro",
        description: error instanceof Error ? error.message : 'Erro ao registrar usuário',
        variant: "destructive",
      });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const value: AuthContextType = {
    ...state,
    login,
    logout,
    register,
    canRegister: state.user?.role === 'master',
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
