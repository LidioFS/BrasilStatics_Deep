
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingDown, TrendingUp, Minus } from 'lucide-react';

interface BetSuggestion {
  type: string;
  description: string;
  odds: string;
  confidence: number;
}

interface BetRiskSelectorProps {
  lowRisk: BetSuggestion;
  mediumRisk: BetSuggestion;
  highRisk: BetSuggestion;
  onSelectBet: (risk: 'low' | 'medium' | 'high', bet: BetSuggestion) => void;
}

const BetRiskSelector: React.FC<BetRiskSelectorProps> = ({
  lowRisk,
  mediumRisk,
  highRisk,
  onSelectBet
}) => {
  return (
    <div className="space-y-3">
      <h4 className="font-semibold text-foreground text-sm mb-3">Sugestões de Apostas</h4>
      
      {/* Low Risk */}
      <Card 
        className="cursor-pointer hover:bg-green-50/50 border-green-200 transition-colors"
        onClick={() => onSelectBet('low', lowRisk)}
      >
        <CardContent className="p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-4 h-4 text-green-600" />
              <Badge variant="outline" className="text-green-600 border-green-600">
                Baixo Risco
              </Badge>
            </div>
            <span className="text-sm font-bold text-green-600">{lowRisk.odds}</span>
          </div>
          <p className="text-xs text-muted-foreground mb-1">{lowRisk.type}</p>
          <p className="text-xs">{lowRisk.description}</p>
          <div className="text-xs text-green-600 mt-1">
            Confiança: {lowRisk.confidence}%
          </div>
        </CardContent>
      </Card>

      {/* Medium Risk */}
      <Card 
        className="cursor-pointer hover:bg-yellow-50/50 border-yellow-200 transition-colors"
        onClick={() => onSelectBet('medium', mediumRisk)}
      >
        <CardContent className="p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Minus className="w-4 h-4 text-yellow-600" />
              <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                Médio Risco
              </Badge>
            </div>
            <span className="text-sm font-bold text-yellow-600">{mediumRisk.odds}</span>
          </div>
          <p className="text-xs text-muted-foreground mb-1">{mediumRisk.type}</p>
          <p className="text-xs">{mediumRisk.description}</p>
          <div className="text-xs text-yellow-600 mt-1">
            Confiança: {mediumRisk.confidence}%
          </div>
        </CardContent>
      </Card>

      {/* High Risk */}
      <Card 
        className="cursor-pointer hover:bg-red-50/50 border-red-200 transition-colors"
        onClick={() => onSelectBet('high', highRisk)}
      >
        <CardContent className="p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-red-600" />
              <Badge variant="outline" className="text-red-600 border-red-600">
                Alto Risco
              </Badge>
            </div>
            <span className="text-sm font-bold text-red-600">{highRisk.odds}</span>
          </div>
          <p className="text-xs text-muted-foreground mb-1">{highRisk.type}</p>
          <p className="text-xs">{highRisk.description}</p>
          <div className="text-xs text-red-600 mt-1">
            Confiança: {highRisk.confidence}%
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BetRiskSelector;
