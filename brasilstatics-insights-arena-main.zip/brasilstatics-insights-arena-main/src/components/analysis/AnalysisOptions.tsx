
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, CornerDownRight, AlertTriangle, Zap, TrendingUp } from 'lucide-react';

interface AnalysisOptionsProps {
  onSelectAnalysis: (type: 'goals' | 'corners' | 'cards' | 'shots' | 'asian_odds') => void;
}

const AnalysisOptions: React.FC<AnalysisOptionsProps> = ({ onSelectAnalysis }) => {
  const analysisTypes = [
    {
      type: 'goals' as const,
      icon: Target,
      title: 'Análise de Gols',
      description: 'Over/Under gols, ambos marcam',
      color: 'text-brasil-green'
    },
    {
      type: 'corners' as const,
      icon: CornerDownRight,
      title: 'Análise de Escanteios',
      description: 'Total de escanteios da partida',
      color: 'text-blue-600'
    },
    {
      type: 'cards' as const,
      icon: AlertTriangle,
      title: 'Análise de Cartões',
      description: 'Cartões amarelos e vermelhos',
      color: 'text-yellow-600'
    },
    {
      type: 'shots' as const,
      icon: Zap,
      title: 'Análise de Chutes',
      description: 'Chutes no gol e fora',
      color: 'text-purple-600'
    },
    {
      type: 'asian_odds' as const,
      icon: TrendingUp,
      title: 'Odds Asiáticas',
      description: 'Handicaps e mercados especiais',
      color: 'text-red-600'
    }
  ];

  return (
    <Card className="card-glass border-brasil-green/20">
      <CardHeader>
        <CardTitle className="text-foreground text-sm">Escolha o Tipo de Análise</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {analysisTypes.map(({ type, icon: Icon, title, description, color }) => (
          <Button
            key={type}
            variant="outline"
            className="w-full justify-start h-auto p-3 border-brasil-green/30 hover:bg-brasil-green/10"
            onClick={() => onSelectAnalysis(type)}
          >
            <div className="flex items-center space-x-3">
              <Icon className={`w-5 h-5 ${color}`} />
              <div className="text-left">
                <div className="font-medium text-foreground text-sm">{title}</div>
                <div className="text-xs text-muted-foreground">{description}</div>
              </div>
            </div>
          </Button>
        ))}
      </CardContent>
    </Card>
  );
};

export default AnalysisOptions;
