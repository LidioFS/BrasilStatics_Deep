
import React from 'react';
import { Target, CornerDownRight, Shield, Zap, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

type AnalysisType = 'goals' | 'corners' | 'cards' | 'shots' | 'asian_odds';

interface AnalysisTypeSelectorProps {
  selectedType: AnalysisType;
  onTypeChange: (type: AnalysisType) => void;
}

const analysisTypes = [
  {
    id: 'goals' as AnalysisType,
    name: 'Gols',
    description: 'Análise de gols esperados e probabilidades',
    icon: Target,
    color: 'bg-green-500'
  },
  {
    id: 'corners' as AnalysisType,
    name: 'Escanteios',
    description: 'Previsões de escanteios e over/under',
    icon: CornerDownRight,
    color: 'bg-blue-500'
  },
  {
    id: 'cards' as AnalysisType,
    name: 'Cartões',
    description: 'Análise de cartões amarelos e vermelhos',
    icon: Shield,
    color: 'bg-yellow-500'
  },
  {
    id: 'shots' as AnalysisType,
    name: 'Finalizações',
    description: 'Estatísticas de chutes e finalizações',
    icon: Zap,
    color: 'bg-purple-500'
  },
  {
    id: 'asian_odds' as AnalysisType,
    name: 'Odds Asiáticas',
    description: 'Handicaps e probabilidades asiáticas',
    icon: TrendingUp,
    color: 'bg-red-500'
  }
];

const AnalysisTypeSelector: React.FC<AnalysisTypeSelectorProps> = ({
  selectedType,
  onTypeChange
}) => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">
        Tipo de Análise
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {analysisTypes.map((type) => {
          const Icon = type.icon;
          const isSelected = selectedType === type.id;
          
          return (
            <Card
              key={type.id}
              className={`
                cursor-pointer transition-all duration-200 hover-brasil-effect
                ${isSelected 
                  ? 'border-brasil-green bg-brasil-green/10' 
                  : 'card-glass border-brasil-green/20 hover:border-brasil-green/40'
                }
              `}
              onClick={() => onTypeChange(type.id)}
            >
              <CardContent className="p-4 text-center">
                <div className={`
                  w-12 h-12 rounded-full ${type.color} flex items-center justify-center mx-auto mb-3
                  ${isSelected ? 'ring-2 ring-brasil-green ring-offset-2 ring-offset-background' : ''}
                `}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h4 className={`font-medium mb-1 ${isSelected ? 'text-brasil-green' : 'text-foreground'}`}>
                  {type.name}
                </h4>
                <p className="text-xs text-muted-foreground">
                  {type.description}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default AnalysisTypeSelector;
