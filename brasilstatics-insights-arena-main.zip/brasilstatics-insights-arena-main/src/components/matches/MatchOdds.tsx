
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MatchOddsProps {
  homeTeam: string;
  awayTeam: string;
  homeOdds?: number;
  drawOdds?: number;
  awayOdds?: number;
  bookmaker?: string;
}

const MatchOdds: React.FC<MatchOddsProps> = ({
  homeTeam,
  awayTeam,
  homeOdds = 2.10,
  drawOdds = 3.40,
  awayOdds = 3.20,
  bookmaker = "Bet365"
}) => {
  const getBestOdd = () => {
    const odds = [
      { type: 'Casa', value: homeOdds, team: homeTeam },
      { type: 'Empate', value: drawOdds, team: 'Empate' },
      { type: 'Fora', value: awayOdds, team: awayTeam }
    ];
    return odds.reduce((prev, curr) => prev.value > curr.value ? prev : curr);
  };

  const bestOdd = getBestOdd();

  return (
    <Card className="border-brasil-green/20 bg-background/50">
      <CardContent className="p-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-muted-foreground">
            Odds - {bookmaker}
          </span>
          <Badge variant="outline" className="text-brasil-green border-brasil-green/30">
            <TrendingUp className="w-3 h-3 mr-1" />
            Melhor: {bestOdd.type}
          </Badge>
        </div>
        
        <div className="grid grid-cols-3 gap-2">
          <div className="text-center">
            <div className="text-xs text-muted-foreground truncate">
              {homeTeam}
            </div>
            <div className={`font-bold text-sm ${homeOdds === bestOdd.value ? 'text-brasil-green' : 'text-foreground'}`}>
              {homeOdds.toFixed(2)}
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-xs text-muted-foreground">
              Empate
            </div>
            <div className={`font-bold text-sm ${drawOdds === bestOdd.value ? 'text-brasil-green' : 'text-foreground'}`}>
              {drawOdds.toFixed(2)}
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-xs text-muted-foreground truncate">
              {awayTeam}
            </div>
            <div className={`font-bold text-sm ${awayOdds === bestOdd.value ? 'text-brasil-green' : 'text-foreground'}`}>
              {awayOdds.toFixed(2)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MatchOdds;
