
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Fixture } from '@/types/football';
import MatchCard from './MatchCard';

interface CompetitionGroupProps {
  competition: string;
  country: string;
  logo?: string;
  flag?: string;
  matches: Fixture[];
  showAnalyzeButton?: boolean;
}

const CompetitionGroup: React.FC<CompetitionGroupProps> = ({
  competition,
  country,
  logo,
  flag,
  matches,
  showAnalyzeButton = true
}) => {
  const getCompetitionIcon = (comp: string) => {
    if (comp.toLowerCase().includes('club world cup') || comp.toLowerCase().includes('mundial')) {
      return '🏆';
    } else if (comp.toLowerCase().includes('premier league')) {
      return '🏴󠁧󠁢󠁥󠁮󠁧󠁿';
    } else if (comp.toLowerCase().includes('la liga')) {
      return '🇪🇸';
    } else if (comp.toLowerCase().includes('bundesliga')) {
      return '🇩🇪';
    } else if (comp.toLowerCase().includes('serie a') && country === 'Italy') {
      return '🇮🇹';
    } else if (comp.toLowerCase().includes('série a') && country === 'Brazil') {
      return '🇧🇷';
    } else if (comp.toLowerCase().includes('ligue 1')) {
      return '🇫🇷';
    }
    return '⚽';
  };

  const liveCount = matches.filter(m => ['LIVE', '1H', '2H', 'HT'].includes(m.status.short)).length;
  const isClubWorldCup = competition.toLowerCase().includes('club world cup') || competition.toLowerCase().includes('mundial');

  return (
    <Card className={`card-glass mb-6 ${isClubWorldCup ? 'border-brasil-green/30 bg-gradient-to-r from-brasil-green/5 to-brasil-yellow/5' : 'border-brasil-green/20'}`}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl">{getCompetitionIcon(competition)}</div>
            <div>
              <CardTitle className="text-foreground text-lg">
                {country}
              </CardTitle>
              <p className="text-sm text-muted-foreground font-medium">
                {competition}
              </p>
            </div>
            {flag && (
              <img src={flag} alt={country} className="w-6 h-6 rounded" />
            )}
          </div>
          <div className="flex items-center space-x-2">
            {liveCount > 0 && (
              <Badge className="bg-red-500 text-white animate-pulse">
                {liveCount} AO VIVO
              </Badge>
            )}
            <Badge variant="outline" className="border-brasil-green text-brasil-green">
              {matches.length} JOGOS
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {matches.map((match) => (
            <div key={match.id} className="border border-brasil-green/10 rounded-lg p-4 bg-background/30">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  {/* Home Team */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <img 
                        src={match.teams.home.logo} 
                        alt={match.teams.home.name}
                        className="w-6 h-6"
                        onError={(e) => {
                          e.currentTarget.src = 'https://via.placeholder.com/24x24?text=H';
                        }}
                      />
                      <span className="font-medium text-foreground">{match.teams.home.name}</span>
                    </div>
                    <div className="text-xl font-bold text-brasil-green">
                      {match.goals.home ?? ''}
                    </div>
                  </div>
                  
                  {/* Away Team */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <img 
                        src={match.teams.away.logo} 
                        alt={match.teams.away.name}
                        className="w-6 h-6"
                        onError={(e) => {
                          e.currentTarget.src = 'https://via.placeholder.com/24x24?text=A';
                        }}
                      />
                      <span className="font-medium text-foreground">{match.teams.away.name}</span>
                    </div>
                    <div className="text-xl font-bold text-brasil-green">
                      {match.goals.away ?? ''}
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col items-center ml-6 space-y-2">
                  <Badge className={`${match.status.short === 'LIVE' || match.status.short === '1H' || match.status.short === '2H' ? 'bg-red-500 text-white animate-pulse' : match.status.short === 'FT' ? 'bg-green-500 text-white' : 'bg-blue-500 text-white'}`}>
                    {match.status.short}
                  </Badge>
                  <div className="text-sm text-muted-foreground text-center">
                    {new Date(match.timestamp * 1000).toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                    {match.status.elapsed && (
                      <div className="text-xs text-brasil-yellow font-medium">
                        {match.status.elapsed}'
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CompetitionGroup;
