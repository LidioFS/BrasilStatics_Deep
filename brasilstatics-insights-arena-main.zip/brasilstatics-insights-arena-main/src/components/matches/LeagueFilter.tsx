
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trophy } from 'lucide-react';

interface LeagueFilterProps {
  selectedLeague: string;
  onLeagueChange: (league: string) => void;
  leagues: Array<{ id: string; name: string; country: string }>;
}

const LeagueFilter: React.FC<LeagueFilterProps> = ({
  selectedLeague,
  onLeagueChange,
  leagues
}) => {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-foreground flex items-center gap-2">
        <Trophy className="w-4 h-4 text-brasil-green" />
        Campeonato
      </label>
      <Select value={selectedLeague} onValueChange={onLeagueChange}>
        <SelectTrigger className="bg-background/50 border-brasil-green/30 focus:border-brasil-green">
          <SelectValue placeholder="Todos os campeonatos" />
        </SelectTrigger>
        <SelectContent className="bg-background border-brasil-green/30">
          <SelectItem value="all">Todos os campeonatos</SelectItem>
          {leagues.map((league) => (
            <SelectItem key={league.id} value={league.id}>
              <div className="flex items-center justify-between w-full">
                <span>{league.name}</span>
                <span className="text-xs text-muted-foreground ml-2">
                  {league.country}
                </span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default LeagueFilter;
