
import React, { useState } from 'react';
import { Clock, MapPin, Brain, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Fixture } from '@/types/football';
import useAIAnalysis, { AnalysisResult } from '@/hooks/useAIAnalysis';
import AnalysisOptions from '@/components/analysis/AnalysisOptions';
import BetRiskSelector from '@/components/analysis/BetRiskSelector';
import MatchOdds from './MatchOdds';

interface MatchCardProps {
  fixture: Fixture;
  onAnalyze?: (fixtureId: number | string) => void;
  showAnalyzeButton?: boolean;
}

const MatchCard: React.FC<MatchCardProps> = ({ 
  fixture, 
  onAnalyze, 
  showAnalyzeButton = true 
}) => {
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [showAnalysisOptions, setShowAnalysisOptions] = useState(false);
  const { analyzeMatch, generateQuickInsight, selectBet, selectedBet, isAnalyzing } = useAIAnalysis();

  const formatTime = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'LIVE':
      case '1H':
      case '2H':
        return 'bg-red-500 animate-pulse';
      case 'HT':
        return 'bg-yellow-500';
      case 'FT':
        return 'bg-green-500';
      case 'NS':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const handleAnalyzeWithType = async (analysisType: 'goals' | 'corners' | 'cards' | 'shots' | 'asian_odds') => {
    try {
      // Convert string id to number for analyzeMatch function
      const fixtureIdNum = typeof fixture.id === 'string' ? parseInt(fixture.id) : fixture.id;
      const result = await analyzeMatch(
        fixtureIdNum,
        fixture.teams.home.name,
        fixture.teams.away.name,
        fixture.league.name,
        analysisType
      );
      setAnalysis(result);
      setShowAnalysis(true);
      setShowAnalysisOptions(false);
      onAnalyze?.(fixture.id);
    } catch (error) {
      console.error('Erro na análise:', error);
    }
  };

  const quickInsight = generateQuickInsight(fixture.teams.home.name, fixture.teams.away.name);
  const isLive = ['LIVE', '1H', '2H', 'HT'].includes(fixture.status.short);

  return (
    <Card className="card-glass border-brasil-green/20 hover-brasil-effect">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img 
              src={fixture.league.logo} 
              alt={fixture.league.name}
              className="w-6 h-6 rounded"
              onError={(e) => {
                e.currentTarget.src = 'https://via.placeholder.com/24x24?text=?';
              }}
            />
            <span className="text-sm font-medium text-foreground">
              {fixture.league.name}
            </span>
          </div>
          <Badge className={`${getStatusColor(fixture.status.short)} text-white`}>
            {fixture.status.short}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Teams */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src={fixture.teams.home.logo} 
                alt={fixture.teams.home.name}
                className="w-8 h-8"
                onError={(e) => {
                  e.currentTarget.src = 'https://via.placeholder.com/32x32?text=H';
                }}
              />
              <span className="font-medium text-foreground">{fixture.teams.home.name}</span>
            </div>
            <span className="text-2xl font-bold text-brasil-green">
              {fixture.goals.home ?? '-'}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src={fixture.teams.away.logo} 
                alt={fixture.teams.away.name}
                className="w-8 h-8"
                onError={(e) => {
                  e.currentTarget.src = 'https://via.placeholder.com/32x32?text=A';
                }}
              />
              <span className="font-medium text-foreground">{fixture.teams.away.name}</span>
            </div>
            <span className="text-2xl font-bold text-brasil-green">
              {fixture.goals.away ?? '-'}
            </span>
          </div>
        </div>

        {/* Match Info */}
        <div className="flex items-center justify-between text-sm text-muted-foreground border-t border-brasil-green/20 pt-3">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{formatTime(fixture.timestamp)}</span>
            </div>
            <div className="text-xs">
              {formatDate(fixture.timestamp)}
            </div>
          </div>
          {fixture.status.elapsed && (
            <div className="text-brasil-yellow font-medium">
              {fixture.status.elapsed}'
            </div>
          )}
        </div>

        {/* Odds */}
        {fixture.odds && (
          <MatchOdds
            homeTeam={fixture.teams.home.name}
            awayTeam={fixture.teams.away.name}
            homeOdds={fixture.odds.home}
            drawOdds={fixture.odds.draw}
            awayOdds={fixture.odds.away}
            bookmaker={fixture.odds.bookmaker}
          />
        )}

        {/* Quick Insight */}
        <div className="bg-brasil-green/5 border border-brasil-green/20 rounded-lg p-3">
          <p className="text-xs text-muted-foreground italic">
            💡 {quickInsight}
          </p>
        </div>

        {/* Analysis Options */}
        {showAnalysisOptions && (
          <AnalysisOptions onSelectAnalysis={handleAnalyzeWithType} />
        )}

        {/* Analysis Results */}
        {showAnalysis && analysis && (
          <div className="bg-background/50 border border-brasil-green/30 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-foreground text-sm">Análise IA</h4>
              <Badge variant="outline" className={`text-xs ${getRiskColor(analysis.riskLevel)}`}>
                Risco: {analysis.riskLevel.toUpperCase()}
              </Badge>
            </div>
            
            <div className="text-center">
              <div className="text-lg font-bold text-brasil-green">
                {analysis.prediction.homeScore} - {analysis.prediction.awayScore}
              </div>
              <div className="text-xs text-muted-foreground">
                Confiança: {analysis.prediction.confidence}%
              </div>
            </div>
            
            <div className="space-y-1">
              {analysis.insights.map((insight, index) => (
                <p key={index} className="text-xs text-muted-foreground">
                  • {insight}
                </p>
              ))}
            </div>
            
            <div className="bg-brasil-green/10 border border-brasil-green/20 rounded p-2">
              <p className="text-xs font-medium text-brasil-green">
                🎯 {analysis.recommendation}
              </p>
            </div>

            {/* Bet Risk Selector */}
            <BetRiskSelector
              lowRisk={analysis.betSuggestions.lowRisk}
              mediumRisk={analysis.betSuggestions.mediumRisk}
              highRisk={analysis.betSuggestions.highRisk}
              onSelectBet={selectBet}
            />

            {/* Selected Bet */}
            {selectedBet && (
              <div className="bg-brasil-yellow/10 border border-brasil-yellow/30 rounded p-3">
                <div className="text-xs font-semibold text-brasil-yellow mb-1">
                  🎯 Aposta Selecionada ({selectedBet.risk.toUpperCase()} RISCO)
                </div>
                <div className="text-xs text-foreground">
                  {selectedBet.bet.type} - {selectedBet.bet.odds}
                </div>
                <div className="text-xs text-muted-foreground">
                  {selectedBet.bet.description}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Actions - Apenas análise funcional */}
        {showAnalyzeButton && (
          <div className="flex space-x-2 pt-2">
            <Button
              onClick={() => setShowAnalysisOptions(!showAnalysisOptions)}
              disabled={isAnalyzing}
              className="flex-1 bg-brasil-green hover:bg-brasil-green/90"
              size="sm"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analisando...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 mr-2" />
                  Analisar com IA
                </>
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MatchCard;
