
export interface League {
  id: number;
  name: string;
  country: string;
  logo: string;
  flag: string;
}

export interface Team {
  id: number;
  name: string;
  logo: string;
}

export interface Fixture {
  id: number | string;
  date: string;
  timestamp: number;
  timezone: string;
  status: {
    long: string;
    short: string;
    elapsed?: number | null;
  };
  league: League;
  teams: {
    home: Team;
    away: Team;
  };
  goals: {
    home: number | null;
    away: number | null;
  };
  score: {
    halftime: {
      home: number | null;
      away: number | null;
    };
    fulltime: {
      home: number | null;
      away: number | null;
    };
  };
  odds?: {
    home: number;
    draw: number;
    away: number;
    bookmaker: string;
  };
}

export interface MatchAnalysis {
  id: string;
  fixtureId: number;
  analysisType: 'goals' | 'corners' | 'cards' | 'shots' | 'asian_odds';
  insights: string[];
  prediction: string;
  confidence: number;
  expectedGoals: {
    home: number;
    away: number;
  };
  corners: {
    total: number;
    overUnder: string;
  };
  cards: {
    total: number;
    redCards: number;
  };
  odds: {
    home: number;
    draw: number;
    away: number;
  };
  bestBookmaker: string;
  createdAt: string;
}

export interface LiveMatch extends Fixture {
  isLive: boolean;
  minute: number;
  events: MatchEvent[];
}

export interface MatchEvent {
  time: {
    elapsed: number;
    extra?: number;
  };
  team: Team;
  player: {
    id: number;
    name: string;
  };
  assist?: {
    id: number;
    name: string;
  };
  type: string;
  detail: string;
}

export interface Prediction {
  id: string;
  fixture: Fixture;
  prediction: string;
  confidence: number;
  odds: number;
  bookmaker: string;
  link: string;
  result?: 'pending' | 'won' | 'lost';
  createdAt: string;
}
