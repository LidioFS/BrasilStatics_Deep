
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  console.log('📨 Football-Data API request:', req.method, req.url);
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    let requestBody;
    try {
      const text = await req.text();
      console.log('📝 Request body:', text);
      
      if (!text || text.trim() === '') {
        requestBody = { endpoint: 'competitions', params: {} };
      } else {
        requestBody = JSON.parse(text);
      }
    } catch (parseError) {
      console.error('❌ JSON parse error:', parseError);
      requestBody = { endpoint: 'competitions', params: {} };
    }

    const { endpoint, params = {} } = requestBody;
    console.log('🎯 Parsed request:', { endpoint, params });
    
    let apiUrl = '';
    const baseUrl = 'https://api.football-data.org/v4';
    
    switch (endpoint) {
      case 'competitions':
        apiUrl = `${baseUrl}/competitions`;
        break;
      case 'matches':
        const date = params?.date;
        if (date) {
          apiUrl = `${baseUrl}/matches?dateFrom=${date}&dateTo=${date}`;
        } else {
          // Se não há data, buscar jogos de hoje
          const today = new Date().toISOString().split('T')[0];
          apiUrl = `${baseUrl}/matches?dateFrom=${today}&dateTo=${today}`;
        }
        break;
      case 'matches-live':
        apiUrl = `${baseUrl}/matches?status=LIVE`;
        break;
      case 'competition-matches':
        const competitionId = params?.competition || 'PL'; // Premier League por padrão
        const matchDate = params?.date;
        if (matchDate) {
          apiUrl = `${baseUrl}/competitions/${competitionId}/matches?dateFrom=${matchDate}&dateTo=${matchDate}`;
        } else {
          apiUrl = `${baseUrl}/competitions/${competitionId}/matches`;
        }
        break;
      default:
        apiUrl = `${baseUrl}/competitions`;
    }

    console.log('🌐 Calling Football-Data API:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'X-Auth-Token': 'YOUR_API_KEY_HERE', // Será substituído por uma chave gratuita
        'Content-Type': 'application/json'
      }
    });

    console.log('📡 API Response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ API Error:', response.status, errorText);
      
      // Retornar dados mock para demonstração
      const mockData = {
        count: 2,
        matches: [
          {
            id: 1,
            utcDate: new Date().toISOString(),
            status: 'SCHEDULED',
            homeTeam: {
              id: 1,
              name: 'Manchester United',
              crest: 'https://crests.football-data.org/66.png'
            },
            awayTeam: {
              id: 2,
              name: 'Liverpool',
              crest: 'https://crests.football-data.org/64.png'
            },
            score: {
              fullTime: { home: null, away: null }
            },
            competition: {
              id: 2021,
              name: 'Premier League',
              emblem: 'https://crests.football-data.org/PL.png'
            }
          },
          {
            id: 2,
            utcDate: new Date(Date.now() + 3600000).toISOString(),
            status: 'SCHEDULED',
            homeTeam: {
              id: 3,
              name: 'Arsenal',
              crest: 'https://crests.football-data.org/57.png'
            },
            awayTeam: {
              id: 4,
              name: 'Chelsea',
              crest: 'https://crests.football-data.org/61.png'
            },
            score: {
              fullTime: { home: null, away: null }
            },
            competition: {
              id: 2021,
              name: 'Premier League',
              emblem: 'https://crests.football-data.org/PL.png'
            }
          }
        ],
        competitions: [
          {
            id: 2021,
            name: 'Premier League',
            emblem: 'https://crests.football-data.org/PL.png',
            area: { name: 'England', flag: 'https://crests.football-data.org/770.png' }
          },
          {
            id: 2014,
            name: 'Primera División',
            emblem: 'https://crests.football-data.org/PD.png',
            area: { name: 'Spain', flag: 'https://crests.football-data.org/760.png' }
          },
          {
            id: 2002,
            name: 'Bundesliga',
            emblem: 'https://crests.football-data.org/BL1.png',
            area: { name: 'Germany', flag: 'https://crests.football-data.org/759.png' }
          }
        ]
      };

      return new Response(JSON.stringify(mockData), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const data = await response.json();
    
    console.log('✅ API Response received:', {
      count: data.count || data.competitions?.length || 0,
      matches: data.matches?.length || 0,
      competitions: data.competitions?.length || 0
    });

    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('💥 Error in football-data function:', error);
    
    // Retornar dados mock em caso de erro
    const mockData = {
      count: 1,
      matches: [
        {
          id: 999,
          utcDate: new Date().toISOString(),
          status: 'SCHEDULED',
          homeTeam: {
            id: 1,
            name: 'Time Casa',
            crest: 'https://via.placeholder.com/64'
          },
          awayTeam: {
            id: 2,
            name: 'Time Visitante',
            crest: 'https://via.placeholder.com/64'
          },
          score: {
            fullTime: { home: null, away: null }
          },
          competition: {
            id: 1,
            name: 'Liga Exemplo',
            emblem: 'https://via.placeholder.com/64'
          }
        }
      ]
    };
    
    return new Response(JSON.stringify(mockData), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
