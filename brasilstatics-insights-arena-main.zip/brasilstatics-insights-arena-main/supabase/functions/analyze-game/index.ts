
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fixture_id, type = 'gols' } = await req.json();
    
    console.log(`Starting analysis for fixture ${fixture_id} with type ${type}`);
    
    // Simulação de análise inteligente mais realista
    const analysisTypes: Record<string, any> = {
      gols: {
        title: "⚽ Análise de Gols",
        insights: [
          `Histórico ofensivo dos times indica média de 2.4 gols por jogo`,
          `Defesas têm permitido 1.8 gols em média nos últimos 5 jogos`,
          `Condições climáticas favoráveis ao jogo ofensivo`,
          `Times costumam marcar mais no segundo tempo (62% dos gols)`
        ],
        prediction: "Over 2.5 gols",
        confidence: Math.floor(Math.random() * 20) + 75, // 75-94%
        odds: "1.85"
      },
      escanteios: {
        title: "🚩 Análise de Escanteios", 
        insights: [
          `Times com estilo ofensivo pelas laterais (18.2 escanteios/jogo)`,
          `Defesas compactas forçam finalizações de fora da área`,
          `Histórico de confrontos diretos: 11.4 escanteios/jogo`,
          `Time visitante tende a pressionar mais (60% dos escanteios)`
        ],
        prediction: "Over 9.5 escanteios",
        confidence: Math.floor(Math.random() * 25) + 70,
        odds: "1.92"
      },
      cartões: {
        title: "🟨 Análise de Cartões",
        insights: [
          `Árbitro tem média de 4.2 cartões por jogo nesta temporada`,
          `Rivalidade histórica entre os times (derby local)`,
          `Jogadores-chave com tendência a faltas táticas`,
          `Importância do jogo pode aumentar a intensidade`
        ],
        prediction: "Over 4.5 cartões",
        confidence: Math.floor(Math.random() * 20) + 78,
        odds: "1.78"
      },
      finalizações: {
        title: "🎯 Análise de Finalizações",
        insights: [
          `Times somam 32.6 finalizações por jogo em média`,
          `Alto volume de chutes de fora da área (42% do total)`,
          `Goleiros com boa média de defesas (6.8 por jogo)`,
          `Estilos ofensivos complementares entre as equipes`
        ],
        prediction: "Over 18.5 finalizações",
        confidence: Math.floor(Math.random() * 15) + 80,
        odds: "1.89"
      }
    };

    const selectedAnalysis = analysisTypes[type] || analysisTypes.gols;
    
    // Criar análise formatada
    const analysis = `${selectedAnalysis.title} - Jogo #${fixture_id}

📊 INSIGHTS PRINCIPAIS:
${selectedAnalysis.insights.map((insight: string, index: number) => `${index + 1}. ${insight}`).join('\n')}

🎯 PREVISÃO: ${selectedAnalysis.prediction}
📈 CONFIANÇA: ${selectedAnalysis.confidence}%
💰 ODDS SUGERIDA: ${selectedAnalysis.odds}

⚡ DICA EXTRA: Acompanhe o primeiro tempo para confirmar o padrão de jogo antes de fazer apostas ao vivo.

🤖 Análise gerada por IA com base em dados históricos e estatísticas avançadas.`;

    console.log(`Analysis completed for fixture ${fixture_id}`);

    // Simular delay de processamento real
    await new Promise(resolve => setTimeout(resolve, 1500));

    return new Response(JSON.stringify({ 
      analysis,
      fixture_id,
      type,
      confidence: selectedAnalysis.confidence,
      prediction: selectedAnalysis.prediction,
      odds: selectedAnalysis.odds,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in analyze-game function:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      analysis: "❌ Erro ao gerar análise. Tente novamente em alguns instantes."
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
