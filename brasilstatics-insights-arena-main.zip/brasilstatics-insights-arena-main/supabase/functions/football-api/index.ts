
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const API_FOOTBALL_KEY = "acd89944b4c245398b4fbfc867dd0e10";
const API_BASE_URL = "https://v3.football.api-sports.io";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  console.log('📨 Received request:', req.method, req.url);
  
  if (req.method === 'OPTIONS') {
    console.log('✅ Handling CORS preflight');
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Ler o corpo da requisição
    let requestBody;
    try {
      const text = await req.text();
      console.log('📝 Raw request body:', text);
      
      if (!text || text.trim() === '') {
        console.error('❌ Empty request body - using default test');
        // Para teste, usar endpoint padrão
        requestBody = { endpoint: 'leagues', params: {} };
      } else {
        requestBody = JSON.parse(text);
      }
    } catch (parseError) {
      console.error('❌ JSON parse error:', parseError);
      // Para teste, usar endpoint padrão
      requestBody = { endpoint: 'leagues', params: {} };
    }

    const { endpoint, params = {} } = requestBody;
    console.log('🎯 Parsed request:', { endpoint, params });
    
    if (!endpoint) {
      throw new Error('Endpoint is required');
    }
    
    let apiUrl = '';
    
    switch (endpoint) {
      case 'leagues':
        apiUrl = `${API_BASE_URL}/leagues`;
        break;
      case 'fixtures':
        const date = params?.date;
        if (!date) {
          throw new Error('Date parameter is required for fixtures endpoint');
        }
        apiUrl = `${API_BASE_URL}/fixtures?date=${date}`;
        if (params.league && params.league !== 'all') {
          apiUrl += `&league=${params.league}`;
        }
        break;
      case 'fixtures-live':
        apiUrl = `${API_BASE_URL}/fixtures?live=all`;
        break;
      case 'fixtures-today':
        const today = new Date().toISOString().split('T')[0];
        apiUrl = `${API_BASE_URL}/fixtures?date=${today}`;
        break;
      default:
        console.error('❌ Unsupported endpoint:', endpoint);
        throw new Error(`Endpoint não suportado: ${endpoint}`);
    }

    console.log('🌐 Calling API-FOOTBALL:', apiUrl);
    console.log('🔑 Using API Key:', API_FOOTBALL_KEY ? `${API_FOOTBALL_KEY.substring(0, 8)}...` : 'Missing');

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': API_FOOTBALL_KEY,
        'X-RapidAPI-Host': 'v3.football.api-sports.io'
      }
    });

    console.log('📡 API Response status:', response.status);
    console.log('📡 API Response headers:', Object.fromEntries(response.headers.entries()));

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ API Error:', response.status, errorText);
      
      // Retornar estrutura padrão em caso de erro
      return new Response(JSON.stringify({
        results: 0,
        response: [],
        errors: [`API Error: ${response.status} - ${errorText}`],
        debug: {
          timestamp: new Date().toISOString(),
          endpoint,
          params,
          api_url: apiUrl,
          status: response.status
        }
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const data = await response.json();
    
    console.log('✅ API Response received:', {
      results: data.results || 0,
      errors: data.errors || [],
      paging: data.paging || {},
      response_length: data.response?.length || 0
    });

    // Log some sample data for debugging
    if (data.response && data.response.length > 0) {
      console.log('📊 Sample response data:', JSON.stringify(data.response.slice(0, 2), null, 2));
    }

    // Garantir estrutura padrão mesmo se a API não retornar dados
    const normalizedData = {
      results: data.results || 0,
      response: data.response || [],
      errors: data.errors || [],
      paging: data.paging || {},
      debug: {
        timestamp: new Date().toISOString(),
        endpoint,
        params,
        api_url: apiUrl
      }
    };

    return new Response(JSON.stringify(normalizedData), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('💥 Error in football-api function:', error);
    console.error('📋 Error stack:', error.stack);
    
    return new Response(JSON.stringify({ 
      results: 0,
      response: [],
      errors: [error.message],
      debug: {
        timestamp: new Date().toISOString(),
        error_type: error.constructor.name,
        error_message: error.message
      }
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
